# ECSDI 2022/2023

Ejemplos y codigo para la practica de ECSDI cuatrimestre de primavera 2022/2023

* `/AgentUtil` Clases con funciones utiles para la practica
* `/Examples/AgentExamples` Plantillas para desarrolar agentes + ejemplos
* `/Exammples/Concurrencia` Ejemplos de la documentacion de laboratorio sobre libreria de concurrencia de python
* `/Examples/Distributed` Ejemplos de sistemas distribuidos de las primeras clases de laboratorio
* `/Examples/flask` Ejemplos de la documentacion de laboratorio sobre libreria flask
* `/Examples/InfoSources` Ejemplos de la documentacion sobre fuentes de datos utiles para la practica
* `/Examples/RDFLib` Ejemplos de la documentacion de laboratorio sobre libreria RDFlib
* `/Ontologias` Ejemplos de ontologias
* `/Python` Notebooks introductorios al lenguaje python