"""
.. module:: __init__.py

__init__.py
*************

:Description: __init__.py

    

:Authors: bejar
    

:Version: 

:Created on: 01/02/2017 15:01 

"""

__author__ = 'bejar'
