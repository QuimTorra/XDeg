"""
.. module:: __init__.py

__init__.py
*************

:Description: __init__.py

    

:Authors: bejar
    

:Version: 

:Created on: 11/02/2015 11:53 

"""

__author__ = 'bejar'
